//
// Created by #Suyghur, on 4/7/21.
//

#ifndef DOLIN_ZAP_BUFFER_HEADER_H
#define DOLIN_ZAP_BUFFER_HEADER_H

#include <string>

namespace dolin_common {
    static const char kMagicHeader = '\x11';

    struct Header {
        char magic;
        size_t log_len;
        size_t log_path_len;
        //未扩展之前原始的路径长度
        size_t base_log_path_len;
        char *log_path;
        //未扩展之前原始的路径
        char *base_log_path;
        //扩展分块序号
        size_t part_num = 1;
        bool compress;
    };

    class BufferHeader {
    public:
        BufferHeader(void *data, size_t size);

        ~BufferHeader();

        void InitHeader(Header &header);

        void *GetOriginPtr();

        void *GetDataPtr();

        void *GetWritePtr();

        Header *GetHeader();

        size_t GetHeaderLen();

        void SetLogLen(size_t len);

        size_t GetLogLen();

        size_t GetLogPathLen();

        char *GetLogPath();

        bool IsCompress();

        bool IsAvailable();

        size_t GetPartNum();

        static size_t CalculateHeaderLen(size_t path_len,size_t base_path_len);

    private:
        char *data_ptr;
        size_t data_size;
    };
}


#endif //DOLIN_ZAP_BUFFER_HEADER_H
