//
// Created by #Suyghur, on 4/19/21.
//

#include "date_kit.h"

std::string DateKit::GetDate() {
    time_t now = time(nullptr);
    tm local_time = *localtime(&now);
    std::string *date;
    size_t buffer_size = sizeof(char) * 20;
    char *buffer = (char *) malloc(buffer_size);
    strftime(buffer, buffer_size, "%Y-%m-%d", &local_time);
    date = new std::string(buffer);
    free(buffer);
    return *date;
}
