package com.dolin.common.util

/**
 * @author #Suyghur.
 * Created on 4/12/21
 */
object CrashUtils {

    fun appendSessionInfo() {

    }
}