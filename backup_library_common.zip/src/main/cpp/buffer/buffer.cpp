//
// Created by #Suyghur, on 4/7/21.
//

#include "buffer.h"
#include "../kit/date_kit.h"

Buffer::Buffer(char *ptr, size_t buffer_size) : buffer_ptr(ptr), buffer_size(buffer_size), buffer_header(buffer_ptr, buffer_size) {}

Buffer::~Buffer() {
    Release();
}

void Buffer::InitData(char *log_folder_path, size_t log_folder_path_len, char *log_date, size_t log_date_len, bool _compress, size_t limit_size) {
    char *log_path = (char *) malloc(log_folder_path_len + separator_len + log_date_len + zap_ext_len);
    sprintf(log_path, "%s%s%s%s", log_folder_path, separator, log_date, zap_ext);
    //获取日期,然后拼接成base_log_name
    //判断base_log_name的大小，如果大于limit_size则加-pnum;
    //定位最新的log_name后设置buffer header头信息中的路径
    std::string date = DateKit::GetDate();
    if (GetCurrentLogFileSize(log_path) >= limit_size) {
        part_num += 1;
    } else {
        InitData(log_folder_path, log_path_len, _compress, part, limit_size);
    }
}

void Buffer::InitData(char *log_path, size_t log_path_len, bool _compress, size_t _part_num, size_t limit_size) {
    std::lock_guard<std::recursive_mutex> lck_release(log_mtx);
    memset(buffer_ptr, '\0', buffer_size);

    dolin_common::Header header{};
    header.magic = kMagicHeader;
    header.log_path_len = log_path_len;
    header.log_path = log_path;
    if (_part_num == 1) {
        header.base_log_path_len = log_path_len;
        header.base_log_path = log_path;
    }
    header.log_len = 0;
    header.compress = _compress;
    header.part_num = _part_num;
    buffer_header.InitHeader(header);
    InitCompress(_compress);

    data_ptr = (char *) buffer_header.GetDataPtr();
    write_ptr = (char *) buffer_header.GetWritePtr();
    limit_file_size = limit_size;

    OpenLogFile(log_path);
}

void Buffer::SetLogLength(size_t len) {
    buffer_header.SetLogLen(len);
}

size_t Buffer::GetLogLength() {
    return write_ptr - data_ptr;
}

size_t Buffer::Append(const char *log, size_t len) {
    std::lock_guard<std::recursive_mutex> lck_append(log_mtx);
    if (GetLogLength() == 0) {
        InitCompress(compress);
    }

    size_t free_size = EmptySize();
    size_t write_size;
    if (compress) {
        zStream.avail_in = (uInt) len;
        zStream.next_in = (Bytef *) log;

        zStream.avail_out = (uInt) free_size;
        zStream.next_out = (Bytef *) write_ptr;

        if (Z_OK != deflate(&zStream, Z_SYNC_FLUSH)) {
            return 0;
        }

        write_size = free_size - zStream.avail_out;
    } else {
        write_size = len <= free_size ? len : free_size;
        memcpy(write_ptr, log, write_size);
    }
    write_ptr += write_size;
    SetLogLength(GetLogLength());
    return write_size;
}

void Buffer::Release() {
    std::lock_guard<std::recursive_mutex> lck_release(log_mtx);
    if (compress && Z_NULL != zStream.state) {
        deflateEnd(&zStream);
    }
    if (map_buffer) {
        munmap(buffer_ptr, buffer_size);
    } else {
        delete[]buffer_ptr;
    }
    if (log_file_ptr != nullptr) {
        fclose(log_file_ptr);
    }
}

size_t Buffer::EmptySize() {
    return buffer_size - (write_ptr - buffer_ptr);
}

char *Buffer::GetLogPath() {
    return buffer_header.GetLogPath();
}

void Buffer::SetFileFlush(FileFlush *flush) {
    file_flush_ptr = flush;
}

void Buffer::CallFileFlush() {
    CallFileFlush(file_flush_ptr);
}

void Buffer::CallFileFlush(FileFlush *flush) {
    CallFileFlush(flush, nullptr);
}

void Buffer::CallFileFlush(FileFlush *flush, Buffer *buffer) {
    if (flush == nullptr) {
        if (buffer != nullptr) {
            delete buffer;
        }
        return;
    }

    std::lock_guard<std::recursive_mutex> lck_flush(log_mtx);
    if (GetLogLength() > 0) {
        if (compress && Z_NULL != zStream.state) {
            deflateEnd(&zStream);
        }
        auto *buffer_flush = new BufferFlush(log_file_ptr);
        buffer_flush->Write(data_ptr, GetLogLength());
        buffer_flush->ReleaseThiz(buffer);
        Clear();
        flush->AsyncFlush(buffer_flush);
    } else {
        delete buffer;
    }
}

void Buffer::ChangeLogPath(char *path) {
    if (log_file_ptr != nullptr) {
        CallFileFlush();
    }
    InitData(path, strlen(path), compress);
}

void Buffer::Clear() {
    std::lock_guard<std::recursive_mutex> lck_clear(log_mtx);
    write_ptr = data_ptr;
    memset(write_ptr, '\0', EmptySize());
    SetLogLength(GetLogLength());
}

bool Buffer::InitCompress(bool _compress) {
    compress = _compress;
    if (compress) {
        zStream.zalloc = Z_NULL;
        zStream.zfree = Z_NULL;
        zStream.opaque = Z_NULL;
        return Z_OK == deflateInit2(&zStream, Z_BEST_COMPRESSION, Z_DEFLATED, -MAX_WBITS, MAX_MEM_LEVEL, Z_DEFAULT_STRATEGY);
    }
    return false;
}

bool Buffer::OpenLogFile(const char *path) {
    if (path != nullptr) {
        FILE *file = fopen(path, "ab+");
        if (file != nullptr) {
            log_file_ptr = file;
//            if (GetCurrentLogFileSize() >= limit_file_size) {
//                //TODO 大于最低限制大小，则创建新的文件,如果文件为2021-04-16.zap，则创建2021-04-16-p2.zap，以此类推
//                part_num += 1;
//            }
            return true;
        }
    }
    return false;
}

size_t Buffer::GetCurrentLogFileSize(const char *path) {
    size_t size = 0;
    if (path != nullptr) {
        FILE *file = fopen(path, "ab+");
        if (file != nullptr) {
            fseek(file, 0, SEEK_END);
            size = ftell(file);
            fclose(file);
        }
    }
    return size;
}

//void Buffer::SetPartNum(size_t part) {
//    part_num = part;
//}

size_t Buffer::GetPartNum() {
    return 0;
}


