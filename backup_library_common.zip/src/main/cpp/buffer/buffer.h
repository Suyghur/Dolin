//
// Created by #Suyghur, on 4/7/21.
//

#ifndef DOLIN_ZAP_BUFFER_H
#define DOLIN_ZAP_BUFFER_H

#include <string>
#include <mutex>
#include <zlib.h>
#include <sys/mman.h>
#include "buffer_header.h"
#include "file_flush.h"

using namespace dolin_common;

class Buffer {
public:

    bool map_buffer = true;

    Buffer(char *ptr, size_t buffer_size);

    ~Buffer();

    void InitData(char *log_folder_path, size_t log_path_len, char *log_date, size_t log_date_len, bool _compress, size_t limit_size);

    void InitData(char *log_path, size_t log_path_len, bool _compress, size_t _part_num, size_t limit_size);

    size_t GetLogLength();

    size_t Append(const char *log, size_t len);

    void Release();

    size_t EmptySize();

    char *GetLogPath();

    size_t GetPartNum();

    void SetFileFlush(FileFlush *flush);

    void CallFileFlush();

    void CallFileFlush(FileFlush *flush);

    void CallFileFlush(FileFlush *flush, Buffer *buffer);

    void ChangeLogPath(char *path);

private:
    FILE *log_file_ptr = nullptr;
    FileFlush *file_flush_ptr = nullptr;
    char *const buffer_ptr = nullptr;
    char *data_ptr = nullptr;
    char *write_ptr = nullptr;
    const char *separator = "/";
    const char *zap_ext = ".zap";
    size_t buffer_size = 0;
    size_t part_num = 1;
    size_t separator_len = 1;
    size_t zap_ext_len = 3;
    std::recursive_mutex log_mtx;
    BufferHeader buffer_header;
    z_stream zStream{};

    bool compress = false;

    void Clear();

    void SetLogLength(size_t len);

    bool InitCompress(bool _compress);

//    void SetPartNum(size_t part);

    bool OpenLogFile(const char *path);

    static size_t GetCurrentLogFileSize(const char *path)
};


#endif //DOLIN_ZAP_BUFFER_H
