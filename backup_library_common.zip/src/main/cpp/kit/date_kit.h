//
// Created by #Suyghur, on 4/19/21.
//

#ifndef DOLIN_DATE_KIT_H
#define DOLIN_DATE_KIT_H


class DateKit {
public:
    static std::string GetDate();

};


#endif //DOLIN_DATE_KIT_H
